# Packet Classifier

## Usage

For example:

```
./main -r ./acl1_256k.txt -p ./acl1_256k_trace.txt
```

or using the script "run.sh"